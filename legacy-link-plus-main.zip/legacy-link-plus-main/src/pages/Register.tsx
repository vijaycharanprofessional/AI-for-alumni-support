import { useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { GraduationCap } from 'lucide-react';
import { storage } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { User, UserRole, StudentProfile, AlumniProfile, AdminProfile } from '@/types';

const Register = () => {
  const { role } = useParams<{ role: UserRole }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState<any>({
    email: '',
    password: '',
    confirmPassword: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: 'Error',
        description: 'Passwords do not match',
        variant: 'destructive',
      });
      setLoading(false);
      return;
    }

    if (storage.getUserByEmail(formData.email)) {
      toast({
        title: 'Error',
        description: 'An account with this email already exists',
        variant: 'destructive',
      });
      setLoading(false);
      return;
    }

    let profile: StudentProfile | AlumniProfile | AdminProfile;

    if (role === 'student') {
      profile = {
        fullName: formData.fullName,
        rollNumber: formData.rollNumber,
        major: formData.major,
        graduationYear: parseInt(formData.graduationYear),
        currentYear: parseInt(formData.currentYear),
        skills: formData.skills ? formData.skills.split(',').map((s: string) => s.trim()) : [],
        interests: formData.interests ? formData.interests.split(',').map((s: string) => s.trim()) : [],
        linkedIn: formData.linkedIn,
        github: formData.github,
        kaggle: formData.kaggle,
      } as StudentProfile;
    } else if (role === 'alumni') {
      profile = {
        fullName: formData.fullName,
        graduationYear: parseInt(formData.graduationYear),
        degree: formData.degree,
        currentJobTitle: formData.currentJobTitle,
        company: formData.company,
        industry: formData.industry,
        isMentor: formData.isMentor === true,
        availability: formData.availability || 'available',
        skills: formData.skills ? formData.skills.split(',').map((s: string) => s.trim()) : [],
        mentorshipAreas: formData.mentorshipAreas ? formData.mentorshipAreas.split(',').map((s: string) => s.trim()) : [],
        location: formData.location,
        linkedIn: formData.linkedIn,
      } as AlumniProfile;
    } else {
      profile = {
        fullName: formData.fullName,
        department: formData.department,
        accessLevel: formData.accessLevel || 'staff',
        role: formData.roleDescription,
        contactInfo: formData.contactInfo,
      } as AdminProfile;
    }

    const user: User = {
      id: Date.now().toString(),
      email: formData.email,
      password: formData.password,
      role: role!,
      profile,
      connections: [],
      pendingConnections: [],
      sentRequests: [],
      createdAt: new Date().toISOString(),
    };

    storage.addUser(user);
    storage.setCurrentUser(user);

    toast({
      title: 'Registration Successful!',
      description: `Welcome to LegacyBot AI, ${profile.fullName}!`,
    });

    setTimeout(() => {
      navigate(`/dashboard/${role}`);
    }, 500);
  };

  const updateField = (field: string, value: any) => {
    setFormData({ ...formData, [field]: value });
  };

  return (
    <div className="min-h-screen bg-muted py-8 px-4">
      <Card className="max-w-2xl mx-auto p-8">
        <div className="flex justify-center mb-6">
          <GraduationCap className="h-12 w-12 text-primary" />
        </div>
        <h1 className="text-2xl font-bold text-center mb-2">
          {role === 'student' && 'Student Registration'}
          {role === 'alumni' && 'Alumni Registration'}
          {role === 'admin' && 'Staff/Admin Registration'}
        </h1>
        <p className="text-center text-muted-foreground mb-6">
          Create your account to get started
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email">Email Address *</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => updateField('email', e.target.value)}
              required
              placeholder="your.email@university.edu"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="password">Password *</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => updateField('password', e.target.value)}
                required
                placeholder="Create a password"
              />
            </div>
            <div>
              <Label htmlFor="confirmPassword">Confirm Password *</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => updateField('confirmPassword', e.target.value)}
                required
                placeholder="Confirm password"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="fullName">Full Name *</Label>
            <Input
              id="fullName"
              value={formData.fullName}
              onChange={(e) => updateField('fullName', e.target.value)}
              required
              placeholder="John Doe"
            />
          </div>

          {role === 'student' && (
            <>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="rollNumber">Roll Number *</Label>
                  <Input
                    id="rollNumber"
                    value={formData.rollNumber}
                    onChange={(e) => updateField('rollNumber', e.target.value)}
                    required
                    placeholder="2024001"
                  />
                </div>
                <div>
                  <Label htmlFor="major">Major *</Label>
                  <Input
                    id="major"
                    value={formData.major}
                    onChange={(e) => updateField('major', e.target.value)}
                    required
                    placeholder="Computer Science"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="graduationYear">Graduation Year *</Label>
                  <Input
                    id="graduationYear"
                    type="number"
                    value={formData.graduationYear}
                    onChange={(e) => updateField('graduationYear', e.target.value)}
                    required
                    placeholder="2026"
                  />
                </div>
                <div>
                  <Label htmlFor="currentYear">Current Year *</Label>
                  <Select onValueChange={(value) => updateField('currentYear', value)} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1st Year</SelectItem>
                      <SelectItem value="2">2nd Year</SelectItem>
                      <SelectItem value="3">3rd Year</SelectItem>
                      <SelectItem value="4">4th Year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="skills">Skills (comma-separated)</Label>
                <Input
                  id="skills"
                  value={formData.skills}
                  onChange={(e) => updateField('skills', e.target.value)}
                  placeholder="Python, React, Machine Learning"
                />
              </div>

              <div>
                <Label htmlFor="interests">Interests (comma-separated)</Label>
                <Input
                  id="interests"
                  value={formData.interests}
                  onChange={(e) => updateField('interests', e.target.value)}
                  placeholder="AI, Web Development, Data Science"
                />
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="linkedIn">LinkedIn</Label>
                  <Input
                    id="linkedIn"
                    value={formData.linkedIn}
                    onChange={(e) => updateField('linkedIn', e.target.value)}
                    placeholder="linkedin.com/in/..."
                  />
                </div>
                <div>
                  <Label htmlFor="github">GitHub</Label>
                  <Input
                    id="github"
                    value={formData.github}
                    onChange={(e) => updateField('github', e.target.value)}
                    placeholder="github.com/..."
                  />
                </div>
                <div>
                  <Label htmlFor="kaggle">Kaggle</Label>
                  <Input
                    id="kaggle"
                    value={formData.kaggle}
                    onChange={(e) => updateField('kaggle', e.target.value)}
                    placeholder="kaggle.com/..."
                  />
                </div>
              </div>
            </>
          )}

          {role === 'alumni' && (
            <>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="graduationYear">Graduation Year *</Label>
                  <Input
                    id="graduationYear"
                    type="number"
                    value={formData.graduationYear}
                    onChange={(e) => updateField('graduationYear', e.target.value)}
                    required
                    placeholder="2020"
                  />
                </div>
                <div>
                  <Label htmlFor="degree">Degree *</Label>
                  <Input
                    id="degree"
                    value={formData.degree}
                    onChange={(e) => updateField('degree', e.target.value)}
                    required
                    placeholder="Bachelor of Science"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="currentJobTitle">Current Job Title *</Label>
                  <Input
                    id="currentJobTitle"
                    value={formData.currentJobTitle}
                    onChange={(e) => updateField('currentJobTitle', e.target.value)}
                    required
                    placeholder="Software Engineer"
                  />
                </div>
                <div>
                  <Label htmlFor="company">Company *</Label>
                  <Input
                    id="company"
                    value={formData.company}
                    onChange={(e) => updateField('company', e.target.value)}
                    required
                    placeholder="Tech Corp"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="industry">Industry *</Label>
                  <Input
                    id="industry"
                    value={formData.industry}
                    onChange={(e) => updateField('industry', e.target.value)}
                    required
                    placeholder="Technology"
                  />
                </div>
                <div>
                  <Label htmlFor="location">Location *</Label>
                  <Input
                    id="location"
                    value={formData.location}
                    onChange={(e) => updateField('location', e.target.value)}
                    required
                    placeholder="San Francisco, CA"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="skills">Skills (comma-separated) *</Label>
                <Input
                  id="skills"
                  value={formData.skills}
                  onChange={(e) => updateField('skills', e.target.value)}
                  required
                  placeholder="Leadership, Software Development"
                />
              </div>

              <div>
                <Label htmlFor="mentorshipAreas">Mentorship Areas (comma-separated)</Label>
                <Input
                  id="mentorshipAreas"
                  value={formData.mentorshipAreas}
                  onChange={(e) => updateField('mentorshipAreas', e.target.value)}
                  placeholder="Career Guidance, Technical Skills"
                />
              </div>

              <div>
                <Label htmlFor="availability">Availability for Mentoring</Label>
                <Select onValueChange={(value) => updateField('availability', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select availability" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="busy">Busy</SelectItem>
                    <SelectItem value="unavailable">Unavailable</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isMentor"
                  checked={formData.isMentor}
                  onCheckedChange={(checked) => updateField('isMentor', checked)}
                />
                <Label htmlFor="isMentor" className="cursor-pointer">
                  I want to be a mentor
                </Label>
              </div>

              <div>
                <Label htmlFor="linkedIn">LinkedIn Profile</Label>
                <Input
                  id="linkedIn"
                  value={formData.linkedIn}
                  onChange={(e) => updateField('linkedIn', e.target.value)}
                  placeholder="linkedin.com/in/..."
                />
              </div>
            </>
          )}

          {role === 'admin' && (
            <>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="department">Department *</Label>
                  <Input
                    id="department"
                    value={formData.department}
                    onChange={(e) => updateField('department', e.target.value)}
                    required
                    placeholder="Student Affairs"
                  />
                </div>
                <div>
                  <Label htmlFor="accessLevel">Access Level *</Label>
                  <Select onValueChange={(value) => updateField('accessLevel', value)} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="staff">Staff</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="roleDescription">Role Description *</Label>
                <Input
                  id="roleDescription"
                  value={formData.roleDescription}
                  onChange={(e) => updateField('roleDescription', e.target.value)}
                  required
                  placeholder="Event Coordinator"
                />
              </div>

              <div>
                <Label htmlFor="contactInfo">Contact Information *</Label>
                <Input
                  id="contactInfo"
                  value={formData.contactInfo}
                  onChange={(e) => updateField('contactInfo', e.target.value)}
                  required
                  placeholder="+1 234 567 8900"
                />
              </div>
            </>
          )}

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'Creating Account...' : 'Create Account'}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link to="/login" className="text-primary hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </Card>
    </div>
  );
};

export default Register;
