import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { GraduationCap, Users, Calendar, LogOut, Plus, TrendingUp } from 'lucide-react';
import { storage } from '@/lib/storage';
import { AdminProfile, Event } from '@/types';
import { useToast } from '@/hooks/use-toast';

const AdminDashboard = () => {
  const [currentUser, setCurrentUser] = useState(storage.getCurrentUser());
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  const [eventForm, setEventForm] = useState({
    title: '',
    category: '',
    description: '',
    date: '',
    location: '',
    maxParticipants: 50,
  });
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const user = storage.getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
  };

  const handleLogout = () => {
    storage.setCurrentUser(null);
    toast({ title: 'Logged out successfully' });
    navigate('/login');
  };

  const getAllUsers = () => storage.getUsers();
  const getStudents = () => getAllUsers().filter(u => u.role === 'student');
  const getAlumni = () => getAllUsers().filter(u => u.role === 'alumni');
  const getEvents = () => storage.getEvents();

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const newEvent: Event = {
      id: Date.now().toString(),
      ...eventForm,
      registeredUsers: [],
      createdBy: currentUser.id,
      createdAt: new Date().toISOString(),
    };

    storage.addEvent(newEvent);
    
    toast({
      title: 'Event Created',
      description: `${newEvent.title} has been created successfully`,
    });

    setShowCreateEvent(false);
    setEventForm({
      title: '',
      category: '',
      description: '',
      date: '',
      location: '',
      maxParticipants: 50,
    });
  };

  const handleDeleteEvent = (eventId: string) => {
    storage.deleteEvent(eventId);
    toast({
      title: 'Event Deleted',
      description: 'The event has been removed',
    });
  };

  if (!currentUser) return null;
  const profile = currentUser.profile as AdminProfile;

  const stats = {
    totalUsers: getAllUsers().length,
    students: getStudents().length,
    alumni: getAlumni().length,
    events: getEvents().length,
    connections: getAllUsers().reduce((acc, u) => acc + u.connections.length, 0) / 2,
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="gradient-primary text-primary-foreground sticky top-0 z-50 shadow-lg">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GraduationCap className="h-8 w-8" />
            <div>
              <h1 className="text-xl font-bold">LegacyBot AI</h1>
              <p className="text-sm opacity-90">Admin Dashboard</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium">{profile.fullName}</p>
              <p className="text-sm opacity-90">{profile.department}</p>
            </div>
            <Button variant="secondary" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid md:grid-cols-5 gap-4 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Users</p>
                <p className="text-3xl font-bold">{stats.totalUsers}</p>
              </div>
              <Users className="h-8 w-8 text-primary" />
            </div>
          </Card>
          
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Students</p>
                <p className="text-3xl font-bold">{stats.students}</p>
              </div>
              <GraduationCap className="h-8 w-8 text-primary" />
            </div>
          </Card>
          
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Alumni</p>
                <p className="text-3xl font-bold">{stats.alumni}</p>
              </div>
              <Users className="h-8 w-8 text-accent" />
            </div>
          </Card>
          
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Events</p>
                <p className="text-3xl font-bold">{stats.events}</p>
              </div>
              <Calendar className="h-8 w-8 text-primary" />
            </div>
          </Card>
          
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Connections</p>
                <p className="text-3xl font-bold">{stats.connections}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-accent" />
            </div>
          </Card>
        </div>

        <Tabs defaultValue="users" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="users">
              <Users className="h-4 w-4 mr-2" />
              User Management
            </TabsTrigger>
            <TabsTrigger value="events">
              <Calendar className="h-4 w-4 mr-2" />
              Event Management
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Students ({stats.students})</h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {getStudents().map((student) => {
                    const profile = student.profile as any;
                    return (
                      <Card key={student.id} className="p-4">
                        <h4 className="font-semibold">{profile.fullName}</h4>
                        <p className="text-sm text-muted-foreground">{profile.major}</p>
                        <p className="text-sm text-muted-foreground">{profile.rollNumber}</p>
                        <div className="mt-2">
                          <Badge variant="outline">{student.connections.length} connections</Badge>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">Alumni ({stats.alumni})</h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {getAlumni().map((alumnus) => {
                    const profile = alumnus.profile as any;
                    return (
                      <Card key={alumnus.id} className="p-4">
                        <h4 className="font-semibold">{profile.fullName}</h4>
                        <p className="text-sm text-muted-foreground">
                          {profile.currentJobTitle} at {profile.company}
                        </p>
                        <div className="mt-2 flex gap-2">
                          <Badge variant="outline">{alumnus.connections.length} connections</Badge>
                          {profile.isMentor && <Badge variant="secondary">Mentor</Badge>}
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="events">
            <div className="space-y-4">
              {!showCreateEvent && (
                <Button onClick={() => setShowCreateEvent(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Create New Event
                </Button>
              )}

              {showCreateEvent && (
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Create New Event</h3>
                  <form onSubmit={handleCreateEvent} className="space-y-4">
                    <div>
                      <Label htmlFor="title">Event Title</Label>
                      <Input
                        id="title"
                        value={eventForm.title}
                        onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })}
                        required
                      />
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="category">Category</Label>
                        <Input
                          id="category"
                          value={eventForm.category}
                          onChange={(e) => setEventForm({ ...eventForm, category: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="date">Date</Label>
                        <Input
                          id="date"
                          type="date"
                          value={eventForm.date}
                          onChange={(e) => setEventForm({ ...eventForm, date: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={eventForm.location}
                        onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={eventForm.description}
                        onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="maxParticipants">Max Participants</Label>
                      <Input
                        id="maxParticipants"
                        type="number"
                        value={eventForm.maxParticipants}
                        onChange={(e) => setEventForm({ ...eventForm, maxParticipants: parseInt(e.target.value) })}
                        required
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button type="submit">Create Event</Button>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setShowCreateEvent(false)}
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </Card>
              )}

              <div className="grid md:grid-cols-2 gap-4">
                {getEvents().map((event) => (
                  <Card key={event.id} className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="font-semibold text-lg">{event.title}</h3>
                        <Badge>{event.category}</Badge>
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDeleteEvent(event.id)}
                      >
                        Delete
                      </Button>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-3">{event.description}</p>
                    
                    <div className="space-y-1 text-sm">
                      <p><strong>Date:</strong> {new Date(event.date).toLocaleDateString()}</p>
                      <p><strong>Location:</strong> {event.location}</p>
                      <p><strong>Registered:</strong> {event.registeredUsers.length} / {event.maxParticipants}</p>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;
