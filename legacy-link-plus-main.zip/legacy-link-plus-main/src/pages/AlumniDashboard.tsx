import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { GraduationCap, MessageSquare, Calendar, Users, LogOut, UserCheck, X } from 'lucide-react';
import { storage } from '@/lib/storage';
import { User, AlumniProfile } from '@/types';
import { useToast } from '@/hooks/use-toast';
import ChatPanel from '@/components/ChatPanel';

const AlumniDashboard = () => {
  const [currentUser, setCurrentUser] = useState(storage.getCurrentUser());
  const [selectedChat, setSelectedChat] = useState<User | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const user = storage.getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
  };

  const handleLogout = () => {
    storage.setCurrentUser(null);
    toast({ title: 'Logged out successfully' });
    navigate('/login');
  };

  const getPendingRequests = () => {
    if (!currentUser) return [];
    return storage.getUsers().filter(u => currentUser.pendingConnections.includes(u.id));
  };

  const getConnections = () => {
    if (!currentUser) return [];
    return storage.getUsers().filter(u => currentUser.connections.includes(u.id));
  };

  const handleAcceptRequest = (userId: string) => {
    if (!currentUser) return;
    
    storage.acceptConnectionRequest(currentUser.id, userId);
    loadData();
    
    const user = storage.getUserById(userId);
    toast({
      title: 'Connection Accepted',
      description: `You are now connected with ${user?.profile.fullName}`,
    });
  };

  const handleRejectRequest = (userId: string) => {
    if (!currentUser) return;
    
    storage.rejectConnectionRequest(currentUser.id, userId);
    loadData();
    
    toast({
      title: 'Request Rejected',
      description: 'Connection request has been rejected',
    });
  };

  const getEvents = () => {
    return storage.getEvents();
  };

  if (!currentUser) return null;
  const profile = currentUser.profile as AlumniProfile;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="gradient-primary text-primary-foreground sticky top-0 z-50 shadow-lg">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GraduationCap className="h-8 w-8" />
            <div>
              <h1 className="text-xl font-bold">LegacyBot AI</h1>
              <p className="text-sm opacity-90">Alumni Dashboard</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium">{profile.fullName}</p>
              <p className="text-sm opacity-90">{profile.company}</p>
            </div>
            <Button variant="secondary" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="requests" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="requests">
              <UserCheck className="h-4 w-4 mr-2" />
              Requests ({getPendingRequests().length})
            </TabsTrigger>
            <TabsTrigger value="connections">
              <Users className="h-4 w-4 mr-2" />
              My Connections
            </TabsTrigger>
            <TabsTrigger value="messages">
              <MessageSquare className="h-4 w-4 mr-2" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="events">
              <Calendar className="h-4 w-4 mr-2" />
              Events
            </TabsTrigger>
          </TabsList>

          <TabsContent value="requests">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {getPendingRequests().map((user) => {
                const userProfile = user.profile as any;
                
                return (
                  <Card key={user.id} className="p-6">
                    <Avatar className="h-12 w-12 mb-4">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {userProfile.fullName?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <h3 className="font-semibold text-lg mb-1">{userProfile.fullName}</h3>
                    <p className="text-sm text-muted-foreground mb-1">
                      {userProfile.major} - {userProfile.currentYear}th Year
                    </p>
                    
                    {userProfile.skills && (
                      <div className="flex flex-wrap gap-1 mb-4 mt-3">
                        {userProfile.skills.slice(0, 3).map((skill: string) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    )}
                    
                    <div className="flex gap-2">
                      <Button 
                        className="flex-1"
                        onClick={() => handleAcceptRequest(user.id)}
                      >
                        <UserCheck className="h-4 w-4 mr-2" />
                        Accept
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => handleRejectRequest(user.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </Card>
                );
              })}
              
              {getPendingRequests().length === 0 && (
                <div className="col-span-full text-center py-12 text-muted-foreground">
                  <UserCheck className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No pending connection requests</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="connections">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {getConnections().map((connection) => {
                const connProfile = connection.profile as any;
                
                return (
                  <Card key={connection.id} className="p-6">
                    <Avatar className="h-12 w-12 mb-4">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {connProfile.fullName?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <h3 className="font-semibold text-lg mb-1">{connProfile.fullName}</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      {connProfile.major || connProfile.currentJobTitle}
                    </p>
                    
                    <Button 
                      className="w-full"
                      onClick={() => setSelectedChat(connection)}
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Open Chat
                    </Button>
                  </Card>
                );
              })}
              
              {getConnections().length === 0 && (
                <div className="col-span-full text-center py-12 text-muted-foreground">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No connections yet. Accept requests to start mentoring!</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="messages">
            {selectedChat ? (
              <ChatPanel 
                currentUser={currentUser} 
                otherUser={selectedChat}
                onClose={() => setSelectedChat(null)}
              />
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Select a connection to start chatting</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="events">
            <div className="grid md:grid-cols-2 gap-4">
              {getEvents().map((event) => (
                <Card key={event.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <Calendar className="h-8 w-8 text-primary" />
                    <Badge>{event.category}</Badge>
                  </div>
                  
                  <h3 className="font-semibold text-lg mb-2">{event.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{event.description}</p>
                  
                  <div className="space-y-2">
                    <p className="text-sm"><strong>Date:</strong> {new Date(event.date).toLocaleDateString()}</p>
                    <p className="text-sm"><strong>Location:</strong> {event.location}</p>
                    <p className="text-sm">
                      <strong>Registered:</strong> {event.registeredUsers.length} / {event.maxParticipants}
                    </p>
                  </div>
                </Card>
              ))}
              
              {getEvents().length === 0 && (
                <div className="col-span-full text-center py-12 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No events available at the moment</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AlumniDashboard;
