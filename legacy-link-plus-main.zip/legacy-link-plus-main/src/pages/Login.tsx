import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { GraduationCap } from 'lucide-react';
import { storage } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const user = storage.getUserByEmail(email);

    if (!user) {
      toast({
        title: 'Login Failed',
        description: 'No account found with this email address.',
        variant: 'destructive',
      });
      setLoading(false);
      return;
    }

    if (user.password !== password) {
      toast({
        title: 'Login Failed',
        description: 'Incorrect password. Please try again.',
        variant: 'destructive',
      });
      setLoading(false);
      return;
    }

    storage.setCurrentUser(user);
    
    toast({
      title: 'Welcome back!',
      description: `Logged in as ${user.profile.fullName}`,
    });

    setTimeout(() => {
      switch (user.role) {
        case 'student':
          navigate('/dashboard/student');
          break;
        case 'alumni':
          navigate('/dashboard/alumni');
          break;
        case 'admin':
          navigate('/dashboard/admin');
          break;
      }
    }, 500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted p-4">
      <Card className="w-full max-w-md p-8">
        <div className="flex justify-center mb-6">
          <GraduationCap className="h-12 w-12 text-primary" />
        </div>
        <h1 className="text-2xl font-bold text-center mb-2">Welcome Back</h1>
        <p className="text-center text-muted-foreground mb-6">
          Sign in to your LegacyBot AI account
        </p>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="your.email@university.edu"
            />
          </div>

          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Enter your password"
            />
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </Button>
        </form>

        <div className="mt-6 text-center space-y-2">
          <p className="text-sm text-muted-foreground">
            Don't have an account?{' '}
            <Link to="/" className="text-primary hover:underline">
              Register here
            </Link>
          </p>
        </div>
      </Card>
    </div>
  );
};

export default Login;
