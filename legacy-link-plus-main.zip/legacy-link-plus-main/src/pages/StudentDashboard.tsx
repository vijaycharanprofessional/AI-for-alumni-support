import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { GraduationCap, MessageSquare, Calendar, Search, Users, LogOut, UserPlus, UserCheck } from 'lucide-react';
import { storage } from '@/lib/storage';
import { User, StudentProfile, Event } from '@/types';
import { useToast } from '@/hooks/use-toast';
import ChatPanel from '@/components/ChatPanel';
import AIAssistant from '@/components/AIAssistant';

const StudentDashboard = () => {
  const [currentUser, setCurrentUser] = useState(storage.getCurrentUser());
  const [alumni, setAlumni] = useState<User[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedChat, setSelectedChat] = useState<User | null>(null);
  const [showAI, setShowAI] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const user = storage.getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
    
    const allUsers = storage.getUsers();
    setAlumni(allUsers.filter(u => u.role === 'alumni'));
    setEvents(storage.getEvents());
  };

  const handleLogout = () => {
    storage.setCurrentUser(null);
    toast({ title: 'Logged out successfully' });
    navigate('/login');
  };

  const handleConnect = (alumniId: string) => {
    if (!currentUser) return;
    
    storage.sendConnectionRequest(currentUser.id, alumniId);
    loadData();
    
    toast({
      title: 'Connection Request Sent',
      description: 'Your request has been sent to the alumni.',
    });
  };

  const getConnectionStatus = (alumniId: string) => {
    if (!currentUser) return null;
    
    if (currentUser.connections.includes(alumniId)) {
      return 'connected';
    }
    if (currentUser.sentRequests.includes(alumniId)) {
      return 'pending';
    }
    return null;
  };

  const getConnections = () => {
    if (!currentUser) return [];
    return storage.getUsers().filter(u => currentUser.connections.includes(u.id));
  };

  const handleRegisterEvent = (eventId: string) => {
    if (!currentUser) return;
    
    const event = events.find(e => e.id === eventId);
    if (event && !event.registeredUsers.includes(currentUser.id)) {
      event.registeredUsers.push(currentUser.id);
      storage.updateEvent(eventId, event);
      loadData();
      
      toast({
        title: 'Registered!',
        description: `You're registered for ${event.title}`,
      });
    }
  };

  if (!currentUser) return null;
  const profile = currentUser.profile as StudentProfile;

  const filteredAlumni = alumni.filter(a => {
    const alumniProfile = a.profile as any;
    const query = searchQuery.toLowerCase();
    return (
      alumniProfile.fullName?.toLowerCase().includes(query) ||
      alumniProfile.company?.toLowerCase().includes(query) ||
      alumniProfile.industry?.toLowerCase().includes(query) ||
      alumniProfile.skills?.some((s: string) => s.toLowerCase().includes(query))
    );
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="gradient-primary text-primary-foreground sticky top-0 z-50 shadow-lg">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GraduationCap className="h-8 w-8" />
            <div>
              <h1 className="text-xl font-bold">LegacyBot AI</h1>
              <p className="text-sm opacity-90">Student Dashboard</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium">{profile.fullName}</p>
              <p className="text-sm opacity-90">{profile.major}</p>
            </div>
            <Button variant="secondary" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="discover" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="discover">
              <Search className="h-4 w-4 mr-2" />
              Discover Alumni
            </TabsTrigger>
            <TabsTrigger value="connections">
              <Users className="h-4 w-4 mr-2" />
              My Connections
            </TabsTrigger>
            <TabsTrigger value="messages">
              <MessageSquare className="h-4 w-4 mr-2" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="events">
              <Calendar className="h-4 w-4 mr-2" />
              Events
            </TabsTrigger>
            <TabsTrigger value="ai" onClick={() => setShowAI(true)}>
              <GraduationCap className="h-4 w-4 mr-2" />
              AI Assistant
            </TabsTrigger>
          </TabsList>

          <TabsContent value="discover" className="space-y-4">
            <div className="flex gap-4 items-center">
              <Input
                placeholder="Search alumni by name, company, industry, or skills..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="max-w-xl"
              />
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAlumni.map((alumnus) => {
                const alumniProfile = alumnus.profile as any;
                const status = getConnectionStatus(alumnus.id);
                
                return (
                  <Card key={alumnus.id} className="p-6 hover:shadow-lg transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {alumniProfile.fullName?.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      {alumniProfile.isMentor && (
                        <Badge variant="secondary">Mentor</Badge>
                      )}
                    </div>
                    
                    <h3 className="font-semibold text-lg mb-1">{alumniProfile.fullName}</h3>
                    <p className="text-sm text-muted-foreground mb-1">
                      {alumniProfile.currentJobTitle} at {alumniProfile.company}
                    </p>
                    <p className="text-sm text-muted-foreground mb-3">{alumniProfile.industry}</p>
                    
                    <div className="flex flex-wrap gap-1 mb-4">
                      {alumniProfile.skills?.slice(0, 3).map((skill: string) => (
                        <Badge key={skill} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                    
                    {status === 'connected' ? (
                      <Button 
                        className="w-full" 
                        variant="default"
                        onClick={() => setSelectedChat(alumnus)}
                      >
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Message
                      </Button>
                    ) : status === 'pending' ? (
                      <Button className="w-full" variant="secondary" disabled>
                        <UserCheck className="h-4 w-4 mr-2" />
                        Request Pending
                      </Button>
                    ) : (
                      <Button 
                        className="w-full" 
                        variant="outline"
                        onClick={() => handleConnect(alumnus.id)}
                      >
                        <UserPlus className="h-4 w-4 mr-2" />
                        Connect
                      </Button>
                    )}
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="connections">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {getConnections().map((connection) => {
                const profile = connection.profile as any;
                
                return (
                  <Card key={connection.id} className="p-6">
                    <Avatar className="h-12 w-12 mb-4">
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {profile.fullName?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <h3 className="font-semibold text-lg mb-1">{profile.fullName}</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      {profile.currentJobTitle || profile.role}
                    </p>
                    
                    <Button 
                      className="w-full" 
                      onClick={() => setSelectedChat(connection)}
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Open Chat
                    </Button>
                  </Card>
                );
              })}
              
              {getConnections().length === 0 && (
                <div className="col-span-full text-center py-12 text-muted-foreground">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No connections yet. Start by discovering alumni!</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="messages">
            {selectedChat ? (
              <ChatPanel 
                currentUser={currentUser} 
                otherUser={selectedChat}
                onClose={() => setSelectedChat(null)}
              />
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Select a connection to start chatting</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="events">
            <div className="grid md:grid-cols-2 gap-4">
              {events.map((event) => (
                <Card key={event.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <Calendar className="h-8 w-8 text-primary" />
                    <Badge>{event.category}</Badge>
                  </div>
                  
                  <h3 className="font-semibold text-lg mb-2">{event.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{event.description}</p>
                  
                  <div className="space-y-2 mb-4">
                    <p className="text-sm"><strong>Date:</strong> {new Date(event.date).toLocaleDateString()}</p>
                    <p className="text-sm"><strong>Location:</strong> {event.location}</p>
                    <p className="text-sm">
                      <strong>Registered:</strong> {event.registeredUsers.length} / {event.maxParticipants}
                    </p>
                  </div>
                  
                  {event.registeredUsers.includes(currentUser.id) ? (
                    <Badge variant="secondary" className="w-full justify-center py-2">
                      Registered
                    </Badge>
                  ) : (
                    <Button 
                      className="w-full"
                      onClick={() => handleRegisterEvent(event.id)}
                      disabled={event.registeredUsers.length >= event.maxParticipants}
                    >
                      Register
                    </Button>
                  )}
                </Card>
              ))}
              
              {events.length === 0 && (
                <div className="col-span-full text-center py-12 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No events available at the moment</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="ai">
            <AIAssistant userRole="student" />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default StudentDashboard;
