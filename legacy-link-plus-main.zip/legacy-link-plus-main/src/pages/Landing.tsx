import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { GraduationCap, Users, Shield, MessageSquare, Calendar, Search } from 'lucide-react';

const Landing = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="gradient-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex justify-center mb-6">
              <GraduationCap className="h-16 w-16" />
            </div>
            <h1 className="text-5xl font-bold mb-6">LegacyBot AI</h1>
            <p className="text-xl mb-8 opacity-90">
              Connect students with alumni. Build meaningful mentorship relationships. 
              Shape the future together.
            </p>
            <div className="flex gap-4 justify-center flex-wrap">
              <Button size="lg" variant="secondary" asChild>
                <Link to="/register/student">Student Registration</Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-white/10 hover:bg-white/20 border-white/30 text-white" asChild>
                <Link to="/register/alumni">Alumni Registration</Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-white/10 hover:bg-white/20 border-white/30 text-white" asChild>
                <Link to="/register/admin">Staff/Admin</Link>
              </Button>
            </div>
            <div className="mt-6">
              <Button variant="link" className="text-white hover:text-white/80" asChild>
                <Link to="/login">Already have an account? Sign in</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Platform Features</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="p-6 hover:shadow-lg transition-shadow">
            <Users className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-xl font-semibold mb-2">Connect & Network</h3>
            <p className="text-muted-foreground">
              Build meaningful connections between students and alumni. Request connections and unlock private messaging.
            </p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <MessageSquare className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-xl font-semibold mb-2">Private Messaging</h3>
            <p className="text-muted-foreground">
              Instagram-style chat system with real-time messaging, file sharing, and AI assistant integration.
            </p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <GraduationCap className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-xl font-semibold mb-2">AI Career Guidance</h3>
            <p className="text-muted-foreground">
              Get personalized career advice, resume feedback, and mentor recommendations from our AI assistant.
            </p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <Calendar className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-xl font-semibold mb-2">Events Management</h3>
            <p className="text-muted-foreground">
              Discover and register for networking events, workshops, and mentorship sessions.
            </p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <Search className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-xl font-semibold mb-2">Advanced Search</h3>
            <p className="text-muted-foreground">
              Find the perfect mentor or mentee with powerful filters by industry, skills, location, and more.
            </p>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <Shield className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-xl font-semibold mb-2">Secure Platform</h3>
            <p className="text-muted-foreground">
              Enterprise-grade security with role-based access control and data protection.
            </p>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-muted py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join thousands of students and alumni building their professional network
          </p>
          <Button size="lg" asChild>
            <Link to="/register/student">Create Your Account</Link>
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-card border-t py-8">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>&copy; 2025 LegacyBot AI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
