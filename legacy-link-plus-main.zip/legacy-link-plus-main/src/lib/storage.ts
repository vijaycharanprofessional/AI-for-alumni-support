import { User, Message, Event } from '@/types';

const USERS_KEY = 'legacybot_users';
const MESSAGES_KEY = 'legacybot_messages';
const EVENTS_KEY = 'legacybot_events';
const CURRENT_USER_KEY = 'legacybot_current_user';

export const storage = {
  // Users
  getUsers(): User[] {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveUsers(users: User[]): void {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },

  addUser(user: User): void {
    const users = this.getUsers();
    users.push(user);
    this.saveUsers(users);
  },

  updateUser(userId: string, updates: Partial<User>): void {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === userId);
    if (index !== -1) {
      users[index] = { ...users[index], ...updates };
      this.saveUsers(users);
      
      const currentUser = this.getCurrentUser();
      if (currentUser?.id === userId) {
        this.setCurrentUser({ ...currentUser, ...updates });
      }
    }
  },

  getUserById(id: string): User | undefined {
    return this.getUsers().find(u => u.id === id);
  },

  getUserByEmail(email: string): User | undefined {
    return this.getUsers().find(u => u.email === email);
  },

  // Current User
  getCurrentUser(): User | null {
    const data = localStorage.getItem(CURRENT_USER_KEY);
    return data ? JSON.parse(data) : null;
  },

  setCurrentUser(user: User | null): void {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  },

  // Messages
  getMessages(): Message[] {
    const data = localStorage.getItem(MESSAGES_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveMessages(messages: Message[]): void {
    localStorage.setItem(MESSAGES_KEY, JSON.stringify(messages));
  },

  addMessage(message: Message): void {
    const messages = this.getMessages();
    messages.push(message);
    this.saveMessages(messages);
  },

  getConversation(userId1: string, userId2: string): Message[] {
    return this.getMessages().filter(
      m => (m.senderId === userId1 && m.receiverId === userId2) ||
           (m.senderId === userId2 && m.receiverId === userId1)
    ).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  },

  markMessagesAsRead(userId: string, otherUserId: string): void {
    const messages = this.getMessages();
    const updated = messages.map(m => {
      if (m.senderId === otherUserId && m.receiverId === userId && !m.read) {
        return { ...m, read: true };
      }
      return m;
    });
    this.saveMessages(updated);
  },

  // Events
  getEvents(): Event[] {
    const data = localStorage.getItem(EVENTS_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveEvents(events: Event[]): void {
    localStorage.setItem(EVENTS_KEY, JSON.stringify(events));
  },

  addEvent(event: Event): void {
    const events = this.getEvents();
    events.push(event);
    this.saveEvents(events);
  },

  updateEvent(eventId: string, updates: Partial<Event>): void {
    const events = this.getEvents();
    const index = events.findIndex(e => e.id === eventId);
    if (index !== -1) {
      events[index] = { ...events[index], ...updates };
      this.saveEvents(events);
    }
  },

  deleteEvent(eventId: string): void {
    const events = this.getEvents().filter(e => e.id !== eventId);
    this.saveEvents(events);
  },

  // Connections
  sendConnectionRequest(fromUserId: string, toUserId: string): void {
    const users = this.getUsers();
    const fromUser = users.find(u => u.id === fromUserId);
    const toUser = users.find(u => u.id === toUserId);

    if (fromUser && toUser) {
      if (!fromUser.sentRequests.includes(toUserId)) {
        fromUser.sentRequests.push(toUserId);
      }
      if (!toUser.pendingConnections.includes(fromUserId)) {
        toUser.pendingConnections.push(fromUserId);
      }
      this.saveUsers(users);
    }
  },

  acceptConnectionRequest(userId: string, requesterId: string): void {
    const users = this.getUsers();
    const user = users.find(u => u.id === userId);
    const requester = users.find(u => u.id === requesterId);

    if (user && requester) {
      user.pendingConnections = user.pendingConnections.filter(id => id !== requesterId);
      requester.sentRequests = requester.sentRequests.filter(id => id !== userId);
      
      if (!user.connections.includes(requesterId)) {
        user.connections.push(requesterId);
      }
      if (!requester.connections.includes(userId)) {
        requester.connections.push(userId);
      }
      
      this.saveUsers(users);
    }
  },

  rejectConnectionRequest(userId: string, requesterId: string): void {
    const users = this.getUsers();
    const user = users.find(u => u.id === userId);
    const requester = users.find(u => u.id === requesterId);

    if (user && requester) {
      user.pendingConnections = user.pendingConnections.filter(id => id !== requesterId);
      requester.sentRequests = requester.sentRequests.filter(id => id !== userId);
      this.saveUsers(users);
    }
  },

  removeConnection(userId: string, connectionId: string): void {
    const users = this.getUsers();
    const user = users.find(u => u.id === userId);
    const connection = users.find(u => u.id === connectionId);

    if (user && connection) {
      user.connections = user.connections.filter(id => id !== connectionId);
      connection.connections = connection.connections.filter(id => id !== userId);
      this.saveUsers(users);
    }
  }
};
