import { Navigate } from 'react-router-dom';
import { storage } from '@/lib/storage';
import { UserRole } from '@/types';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
}

const ProtectedRoute = ({ children, allowedRoles }: ProtectedRouteProps) => {
  const currentUser = storage.getCurrentUser();

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(currentUser.role)) {
    return <Navigate to={`/dashboard/${currentUser.role}`} replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
