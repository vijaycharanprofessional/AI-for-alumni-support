export type UserRole = 'student' | 'alumni' | 'admin';

export interface User {
  id: string;
  email: string;
  password: string;
  role: UserRole;
  profile: StudentProfile | AlumniProfile | AdminProfile;
  connections: string[];
  pendingConnections: string[];
  sentRequests: string[];
  createdAt: string;
}

export interface StudentProfile {
  fullName: string;
  rollNumber: string;
  major: string;
  graduationYear: number;
  currentYear: number;
  skills: string[];
  interests: string[];
  profilePhoto?: string;
  linkedIn?: string;
  github?: string;
  kaggle?: string;
}

export interface AlumniProfile {
  fullName: string;
  graduationYear: number;
  degree: string;
  currentJobTitle: string;
  company: string;
  industry: string;
  isMentor: boolean;
  availability: 'available' | 'busy' | 'unavailable';
  skills: string[];
  mentorshipAreas: string[];
  location: string;
  linkedIn?: string;
  profilePhoto?: string;
}

export interface AdminProfile {
  fullName: string;
  department: string;
  accessLevel: 'admin' | 'staff';
  role: string;
  contactInfo: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
}

export interface Event {
  id: string;
  title: string;
  category: string;
  description: string;
  date: string;
  location: string;
  maxParticipants: number;
  registeredUsers: string[];
  createdBy: string;
  createdAt: string;
}

export interface Connection {
  userId: string;
  status: 'pending' | 'accepted' | 'rejected';
  timestamp: string;
}
